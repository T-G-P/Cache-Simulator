#! /usr/bin/python


test_list = ["test1","test2", "test3", "test4", "test5"]

path_prefix = "../../../"
tests = {
"test1" : ["./cache-sim -l1size 4096 -l1assoc direct -l2size 16384 -l2assoc assoc -l3size 65536 -l3assoc assoc 16 FIFO " + path_prefix + "lslongtrace.txt", "trace1"],
"test2" : ["./cache-sim -l1size 4096 -l1assoc direct -l2size 16384 -l2assoc assoc -l3size 65536 -l3assoc assoc 16 LRU " + path_prefix + "lslongtrace.txt", "trace2"],
"test3" : ["./cache-sim -l1size 4096 -l1assoc direct -l2size 16384 -l2assoc assoc -l3size 65536 -l3assoc assoc 16 FIFO " + path_prefix + "gcctrace_short.txt", "trace3"],
"test4" : ["./cache-sim -l1size 4096 -l1assoc assoc:4 -l2size 16384 -l2assoc assoc:8 -l3size 65536 -l3assoc assoc:8 16 FIFO " + path_prefix + "lslongtrace.txt", "trace4"],
"test5" : ["./cache-sim -l1size 4096 -l1assoc assoc:4 -l2size 16384 -l2assoc assoc:8 -l3size 65536 -l3assoc assoc:8 16 LRU " + path_prefix + "lslongtrace.txt", "trace5"],
"test6" : ["./cache-sim -l1size <L1 size> -l1assoc <L1 assoc> -l2size <L2 size> -l2assoc <L2 assoc> -l3size <L3 size> -l3assoc <L3 assoc> <block size> <replace alg> " + path_prefix + "lslongtrace.txt", "trace1"],
"test7" : ["./cache-sim -l1size <L1 size> -l1assoc <L1 assoc> -l2size <L2 size> -l2assoc <L2 assoc> -l3size <L3 size> -l3assoc <L3 assoc> <block size> <replace alg> " + path_prefix + "lslongtrace.txt", "trace1"],
"test8" : ["./cache-sim -l1size <L1 size> -l1assoc <L1 assoc> -l2size <L2 size> -l2assoc <L2 assoc> -l3size <L3 size> -l3assoc <L3 assoc> <block size> <replace alg> " + path_prefix + "lslongtrace.txt", "trace1"],
"test9" : ["./cache-sim -l1size <L1 size> -l1assoc <L1 assoc> -l2size <L2 size> -l2assoc <L2 assoc> -l3size <L3 size> -l3assoc <L3 assoc> <block size> <replace alg> " + path_prefix + "lslongtrace.txt", "trace1"],
"test10" : ["./cache-sim -l1size <L1 size> -l1assoc <L1 assoc> -l2size <L2 size> -l2assoc <L2 assoc> -l3size <L3 size> -l3assoc <L3 assoc> <block size> <replace alg> " + path_prefix + "lslongtrace.txt", "trace1"],
}
