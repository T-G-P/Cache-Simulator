#! /usr/bin/env python2.7

import sys, string, os, re, popen2, difflib, platform, shutil, stat
from tests import *

class ExperimentError(Exception):
    def __init__(self, command, output):
        self.command = command
        limit = 10000
        if(len(output) > limit):
          self.output = output[:limit/2] + "\n\n...TRUNCATED...\n\n" + output[-limit/2:]
        else:
          self.output = output
    def __str__(self):
        return "ExperimentError:" + `self.command`

def run_command(command_string, input_string="", max_lines=0, verbose=False, echo=True, throw_exception=True, return_valgrind_output=False):

    if echo:
        print "executing:", command_string
    obj = popen2.Popen4(command_string)
    output = ""
    valgrind_output = ""

    obj.tochild.write(input_string)
    obj.tochild.close()
    valgrind_prefix = "==%d==" % obj.pid
    line = obj.fromchild.readline()
    while (line):
        if verbose == 1:
            print line,
        if line.startswith(valgrind_prefix):
            valgrind_output += line
        output += line
        line = obj.fromchild.readline()
    exit_status = obj.wait()

    if(max_lines != 0):
        lines = output.split("\n");
        output = string.join(lines[-max_lines:], "\n")

    if throw_exception and exit_status != 0:
        raise ExperimentError(command_string, output)

    if return_valgrind_output:
        return valgrind_output
    else:
        return output


##############main code############################


if len(sys.argv) <= 1:
    print "error in arguments"
    sys.exit(1);

print "test_file: ", sys.argv[1]

## create a temp directory ########

backup_path = os.getcwd();
if os.path.exists("obj_temp"):
    print "deleting obj_temp directory"
    try:
	    run_command("rm -rf obj_temp", verbose=False);
    except:
	print "Failed to delete obj_temp"
	sys.exit(2)

run_command("mkdir obj_temp", verbose=False);
os.chdir("obj_temp");

### copy the tar.gz file ##########

tar_file_path = sys.argv[1];
tar_file_name = "pa3.tar";
if not os.path.exists("../" + tar_file_path):
    print "there is no tar file in the directory";
    sys.exit(1);
shutil.copyfile("../" + tar_file_path, "./" + tar_file_name)

##### untar the file ###############

run_command("tar -xf " + tar_file_name);

# Fix permissions on unpacked files
os.chmod("pa3", stat.S_IRWXU);
os.system("chmod 0644 pa3/simulator/*");
os.chdir("pa3/simulator");

run_command("rm -f cache-sim", verbose=True);
run_command("make", verbose=True);


if not os.path.exists("cache-sim"):
    print "binary is not built, error in build"
    sys.exit(1);


print "Checking basic cache miss rate:"

for test in test_list:

    test_param = tests[test];

    result_file = test_param[1];
    test_command = test_param[0];

    print result_file, test_command
    run_command(test_command + " > temp.txt");
    
    print "Running test case: ", test
    run_command("awk 'NR == 1 {print $3}' temp.txt > numbers.txt", verbose=False);
    run_command("awk 'NR == 2, NR == 10 {print $4}' temp.txt >> numbers.txt", verbose=False);
    
    run_command("awk 'NR == 1 {print $3}' ../../../" + result_file + " > SolutionNumbers.txt", verbose=False);
    run_command("awk 'NR == 2, NR == 10 {print $4}' ../../../" + result_file + " >> SolutionNumbers.txt", verbose=False);
    
    prog_result_path = "../../../" + result_file;
    run_command("diff -b SolutionNumbers.txt numbers.txt")

print "Basic Hit/Miss computation succeeded"


# print "Checking capacity/conflict miss computation:"

# for test in test_list:

#     test_param = tests[test];

#     result_file = test_param[1];
#     test_command = test_param[0];

#     print result_file, test_command

#     print "Running test:", test
#     run_command(test_command + " > temp.txt");
    

#     run_command("awk 'NR == 1 {print $3}' temp.txt > numbers.txt", verbose=False);
#     run_command("awk 'NR == 2, NR == 12 {print $4}' temp.txt >> numbers.txt", verbose=False);
    
#     run_command("awk 'NR == 1 {print $3}' ../../" + result_file + " > SolutionNumbers.txt", verbose=False);
#     run_command("awk 'NR == 2, NR == 12 {print $4}' ../../" + result_file + " >> SolutionNumbers.txt", verbose=False);
    
#     prog_result_path = "../../" + result_file;
#     run_command("diff -b SolutionNumbers.txt numbers.txt", verbose=False)




# print "Conflict/Capacity Miss Basic computation successful"


